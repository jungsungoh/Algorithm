package Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dto.ProductDto;
import Dto.UserDto;
import Service.LoginService;
import Service.LoginServiceImpl;
import Service.ProductService;
import Service.ProductServiceImpl;

@WebServlet("/main.do")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static LoginService loginService;
	private static ProductService productService;
	
	public void init() {
		loginService = new LoginServiceImpl();
		productService = new ProductServiceImpl();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		process(request, response);
	}
	private void process(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		String act = request.getParameter("act");
		String root = request.getContextPath();
		String path = "/index.jsp";
		if("login".equals(act)) {
			login(request,response);
		}else if("logout".equals(act)) {
			logout(request,response);
		}else if("reg_product".equals(act)) {
			path = "/register.jsp";
			response.sendRedirect(root+path);
		}else if("reg".equals(act)) {
			register(request,response);
		}else if("last_reg".equals(act)) {
			last(request,response);
		}
	}
	private void login(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		String userid = request.getParameter("userid");
		String userpw = request.getParameter("userpw");
		try {
			UserDto user = loginService.login(userid, userpw);
			if(user != null) {
				HttpSession session = request.getSession();
				session.setAttribute("userInfo", user);
				path = "/index.jsp";
			}else { 
				request.setAttribute("msg","아이디 또는 비밀번호를 확인 해 주세요.");
				path = "/index.jsp";
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		request.getRequestDispatcher(path).forward(request, response);
	}
	private void logout(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
		HttpSession session = request.getSession();
		String root = request.getContextPath();
		UserDto user = (UserDto) session.getAttribute("userInfo");
		String path = "/index.jsp";
		if(user != null) {
			session.removeAttribute("userInfo");
			path = "/index.jsp";
		}
		response.sendRedirect(root+path);
	}
	private void register(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
		String path = "/index.jsp";
		int p_num = Integer.parseInt(request.getParameter("p_num"));
		String p_name = request.getParameter("p_name");
		int p_price = Integer.parseInt(request.getParameter("p_price"));
		String p_desc = request.getParameter("p_desc");
		
		try {
			productService.register(p_num, p_name, p_price, p_desc);
			request.setAttribute("msg", "입력 완료!");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			request.setAttribute("msg", "입력 실패했습니다!");
			e.printStackTrace();
		}
		request.getRequestDispatcher(path).forward(request, response);
	}
	private void last(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
		String path = "/lastproduct.jsp";
		String root = request.getContextPath();
		HttpSession session = request.getSession();
		UserDto user = (UserDto) session.getAttribute("userInfo");
		try {
			ProductDto product = productService.select_product(user.getId());
			Cookie numCookie = new Cookie("p_num", String.valueOf(product.getP_num()));
			Cookie nameCookie = new Cookie("p_name", product.getP_name());
			Cookie priceCookie = new Cookie("p_price", String.valueOf(product.getP_price()));
			Cookie descCookie = new Cookie("p_desc",product.getP_desc());
			numCookie.setMaxAge(60);
			nameCookie.setMaxAge(60);
			priceCookie.setMaxAge(60);
			descCookie.setMaxAge(60);
			response.addCookie(numCookie);
			response.addCookie(nameCookie);
			response.addCookie(priceCookie);
			response.addCookie(descCookie);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.getRequestDispatcher(path).forward(request, response);
	}
}
