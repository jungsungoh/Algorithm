package Service;

import Dto.UserDto;

public interface LoginService {
	public UserDto login(String userid, String userpwd) throws Exception;
}
