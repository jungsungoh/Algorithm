package Service;

import DAO.ProductDao;
import DAO.ProductDaoImpl;
import Dto.ProductDto;

public class ProductServiceImpl implements ProductService {
	ProductDao productdao;
	
	public ProductServiceImpl() {
		productdao = new ProductDaoImpl();
	}
	@Override
	public void register(int p_num, String p_name, int p_price, String p_desc) throws Exception {
		if(p_num == 0 || p_name == null || p_price == 0 || p_desc == null) {
			throw new Exception(); 
		}
		productdao.insert_product(p_num, p_name, p_price, p_desc);
	}
	public ProductDto select_product(String user_id) throws Exception {
		if(user_id == null) {
			throw new Exception();
		}
		return productdao.select_product(user_id);
	}

}
