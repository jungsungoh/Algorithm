package Service;

import DAO.LoginDao;
import DAO.LoginDaoImpl;
import Dto.UserDto;

public class LoginServiceImpl implements LoginService{
	LoginDao loginDao;
	
	public LoginServiceImpl() {
		loginDao = new LoginDaoImpl();
	}

	@Override
	public UserDto login(String userid, String userpwd) throws Exception {
		if(userid == null || userpwd == null) {
			throw new Exception();
		}
		return loginDao.login(userid, userpwd);
	}
}
