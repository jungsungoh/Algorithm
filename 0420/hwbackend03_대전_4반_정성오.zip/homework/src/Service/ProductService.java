package Service;

import Dto.ProductDto;

public interface ProductService {
	public void register(int p_num,String p_name, int p_price, String p_desc) throws Exception;
	public ProductDto select_product(String user_id) throws Exception;
}
