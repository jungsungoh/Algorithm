package Dto;

public class ProductDto {
	int p_num, p_price;
	String p_name, p_desc;
	public ProductDto() {}
	public ProductDto(int p_num, int p_price, String p_name, String p_desc) {
		super();
		this.p_num = p_num;
		this.p_price = p_price;
		this.p_name = p_name;
		this.p_desc = p_desc;
	}
	public int getP_num() {
		return p_num;
	}
	public void setP_num(int p_num) {
		this.p_num = p_num;
	}
	public int getP_price() {
		return p_price;
	}
	public void setP_price(int p_price) {
		this.p_price = p_price;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getP_desc() {
		return p_desc;
	}
	public void setP_desc(String p_desc) {
		this.p_desc = p_desc;
	};
	
	
}
