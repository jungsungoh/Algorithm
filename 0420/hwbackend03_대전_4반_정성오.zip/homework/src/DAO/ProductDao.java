package DAO;

import Dto.ProductDto;

public interface ProductDao {
	public void insert_product(int p_num, String p_name, int p_price, String p_desc);
	public ProductDto select_product(String user_id);
}
