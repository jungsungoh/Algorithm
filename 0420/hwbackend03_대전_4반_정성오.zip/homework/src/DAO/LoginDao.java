package DAO;

import java.sql.SQLException;

import Dto.UserDto;


public interface LoginDao {
	public UserDto login(String userid, String userpwd) throws SQLException;
}
