package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Dto.ProductDto;
import Util.DBUtil;

public class ProductDaoImpl implements ProductDao{

	@Override
	public void insert_product(int p_num, String p_name, int p_price, String p_desc) {
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("insert into product (p_num,p_name,p_price,p_desc) \n");
			sql.append("values(?,?,?,?)");
			
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, p_num);
			pstmt.setString(2, p_name);
			pstmt.setInt(3, p_price);
			pstmt.setString(4, p_desc);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.close(con);
			DBUtil.close(pstmt);
		}
		
	}

	@Override
	public ProductDto select_product(String user_id) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ProductDto product = null;
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select * from product where user_id = ?");
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, user_id);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				product = new ProductDto();
				product.setP_num(rs.getInt("p_num"));
				product.setP_name(rs.getString("p_name"));
				product.setP_price(rs.getInt("p_price"));
				product.setP_desc(rs.getString("p_desc"));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			product = null;
		}finally {
			DBUtil.close(con);
			DBUtil.close(pstmt);
			DBUtil.close(rs);
		}
		return product;
		
	}

}
