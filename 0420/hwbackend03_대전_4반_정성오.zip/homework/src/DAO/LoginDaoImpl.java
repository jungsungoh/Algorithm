package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Dto.UserDto;
import Util.DBUtil;

public class LoginDaoImpl implements LoginDao{

	@Override
	public UserDto login(String userid, String userpwd) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		UserDto user = null;
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select username, userid, email \n");
			sql.append("from ssafy_member \n");
			sql.append("where userid = ? and userpwd = ?");
			
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, userid);
			pstmt.setString(2, userpwd);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				user = new UserDto();
				user.setId(rs.getString("userid"));
				user.setName(rs.getString("username"));
				user.setEmail(rs.getString("email"));
			}
		}catch(SQLException e) {
			e.printStackTrace();
			user = null;
		} finally {
			DBUtil.close(con);
			DBUtil.close(rs);
			DBUtil.close(pstmt);
		}
		return user;
	}

}
