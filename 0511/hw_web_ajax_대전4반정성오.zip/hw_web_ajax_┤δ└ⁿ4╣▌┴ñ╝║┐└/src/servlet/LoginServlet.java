package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dto.userDTO;
import service.userService;

@WebServlet("/login.do")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private userService userservice;
	public void init() {
		userservice = new userService();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}
	protected void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String root = request.getContextPath();
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String command = request.getParameter("command");
		System.out.println(command);
		if(command.equals("login")) {
			login_function(request,response);
		}else if(command.equals("idcheck")) {
			idcheck_function(request,response);
		}else if(command.equals("register")) {
			String path = "/register.jsp";
			response.sendRedirect(root+path);
		}else if(command.equals("register_request")) {
			
		}
	}
	protected void login_function(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/login.jsp";
		String id = request.getParameter("user_id");
		String pw = request.getParameter("user_pw");
		userDTO user = userservice.login(id, pw);
		PrintWriter writer = response.getWriter();
		if(user == null) {
			writer.print(0);
		}else {
			path = "/mainpage.jsp";
			HttpSession session = request.getSession();
			session.setAttribute("userinfo", user);
			//request.getRequestDispatcher(path).forward(request, response);
			writer.print(1);
		}
		writer.close();
	}
	protected void idcheck_function(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/login.jsp";
		String id = request.getParameter("user_id");
		userDTO user = userservice.login(id);
		PrintWriter writer = response.getWriter();
		if(user == null) {
			writer.print(0);
		}else {
			writer.print(1);
		}
		writer.close();
	}
	protected void register_function(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("user_id");
		String pw = request.getParameter("user_pw");
		String name = request.getParameter("user_name");
		String email = request.getParameter("user_email");
		
		int flag = userservice.register(new userDTO(id,pw,name,email));
		PrintWriter writer = response.getWriter();
		if(flag == 0) {
			writer.print(0);
		}else {
			writer.print(1);
		}
		writer.close();
	}
}
