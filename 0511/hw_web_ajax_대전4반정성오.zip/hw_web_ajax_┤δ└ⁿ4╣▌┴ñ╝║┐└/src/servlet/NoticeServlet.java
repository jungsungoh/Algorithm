package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dto.NoticeDTO;
import dto.userDTO;
import service.NoticeService;


@WebServlet("/notice.do")
public class NoticeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private NoticeService noticeService;
	public void init() {
		noticeService = new NoticeService();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		process(request,response);
	}
	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String root = request.getContextPath();
		String path = "/login.jsp";

		String act = request.getParameter("act");
		if(act.equals("get_list")){
			get_list(request,response);
		}else if(act.equals("search")) {
			search(request,response);
		}else if(act.equals("write_notice")) {
			path = "/mainpage.jsp";
			response.sendRedirect(root+path);
		}
		else if(act.equals("return")) {
			path = "/mainpage.jsp";
			response.sendRedirect(root+path);
		}
	}
	private void search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String path = "/login.jsp";
		HttpSession session = request.getSession();
		String page = request.getParameter("page");
		String value = "";
		String param = "";
		int startPage = 0;
		int onePageCnt = 10;
		if(page != null) {
			startPage = (Integer.parseInt(page)-1)*onePageCnt;
			value = (String)session.getAttribute("search_val");
			param = (String)session.getAttribute("search_opt");
		}else {
			value = request.getParameter("search_val");
			param = request.getParameter("search_opt");
			session.setAttribute("search_val", value);
			session.setAttribute("search_opt", param);
		}
		List<NoticeDTO> list = null;
		if(param.equals("writer")) {
			int count = noticeService.selectCnt(0,value);
			count = (int)Math.ceil((double)count/(double)onePageCnt);
			session.setAttribute("ncount",count);
			list = noticeService.search_opt(0,value,startPage,onePageCnt);
		}else if(param.equals("title")){
			int count = noticeService.selectCnt(1,value);
			count = (int)Math.ceil((double)count/(double)onePageCnt);
			session.setAttribute("ncount",count);
			list = noticeService.search_opt(1, value,startPage,onePageCnt);
		}
		if(list!=null) {
			request.setAttribute("npage", page);
			session.setAttribute("flag",2);
			session.setAttribute("nlist", list);
			path = "/mainpage.jsp";
		}else {
			request.setAttribute("msg", "공지사항 정보가 존재하지 않습니다!");
		}
		request.getRequestDispatcher(path).forward(request, response);
	}
	private void get_list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String path = "/login.jsp";
		HttpSession session = request.getSession();
		String page = request.getParameter("page");
		int count = noticeService.selectCnt();
		int startPage = 0;
		int onePageCnt = 10;
		count = (int)Math.ceil((double)count/(double)onePageCnt);
		session.setAttribute("ncount",count);
		if(page != null) {
			startPage = (Integer.parseInt(page)-1)*onePageCnt;
		}
		List<NoticeDTO> list_page = noticeService.selectPage(startPage, onePageCnt);
		if(list_page!=null) {
			request.setAttribute("npage", page);
			session.setAttribute("flag",1);
			session.setAttribute("nlist", list_page);
			path = "/notice.jsp";
		}else {
			request.setAttribute("msg", "공지사항 정보가 존재하지 않습니다!");
		}
		request.getRequestDispatcher(path).forward(request, response);
	}
}
