package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import dto.NoticeDTO;
import util.DBUtil;


public class NoticeDao {
	public int selectCnt() {
		int result = 0;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select count(*) from notice");
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			if(rs.next()) {
				result = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.close(con);
			DBUtil.close(rs);
			DBUtil.close(pstmt);
		}
		return result;
	}
	public int selectCnt(int flag, String val) {
		int result = 0;
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		List<NoticeDTO> list = new ArrayList<>();
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			if(flag ==0) { 
				sql.append("select count(*) from notice where id = ?");
				pstmt = con.prepareStatement(sql.toString());
				if(val != null && !val.trim().equals("")){
					pstmt.setString(1, val);
				}
				rs = pstmt.executeQuery();
			}
			else if(flag ==1) {
				sql.append("select count(*) from notice where title like ?");
				pstmt = con.prepareStatement(sql.toString());
				if(val != null && !val.trim().equals("")){
					pstmt.setString(1, "%"+val+"%");
				}
				rs = pstmt.executeQuery();
			}
			if(rs.next()) {
				result = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.close(con);
			DBUtil.close(rs);
			DBUtil.close(pstmt);
		}
		return result;
	}
	public List<NoticeDTO> selectPage(int start, int pageCnt){
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<NoticeDTO> list = new ArrayList<>();
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select * from notice limit ?, ?");
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, start);
			pstmt.setInt(2, pageCnt);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				NoticeDTO n = new NoticeDTO();
				n.setNum(rs.getInt("num"));
				n.setTitle(rs.getString("title"));
				n.setDate(rs.getString("date"));
				n.setId(rs.getString("id"));
				n.setContent(rs.getString("content"));
				list.add(n);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.close(con);
			DBUtil.close(rs);
			DBUtil.close(pstmt);
		}
		return list;
	}
	public List<NoticeDTO> search_opt(int flag,String val,int start,int pageCnt) {
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		List<NoticeDTO> list = new ArrayList<>();
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			if(flag ==0) { // param = writer
				sql.append("select * from notice where id = ?");
				sql.append(" limit ?,?");
				pstmt = con.prepareStatement(sql.toString());
				if(val != null && !val.trim().equals("")){
					pstmt.setString(1, val);
					pstmt.setInt(2, start);
					pstmt.setInt(3, pageCnt);
				}
				rs = pstmt.executeQuery();
			}
			else if(flag ==1) {
				sql.append("select * from notice where title like ?");
				sql.append(" limit ?,?");
				pstmt = con.prepareStatement(sql.toString());
				if(val != null && !val.trim().equals("")){
					pstmt.setString(1, "%"+val+"%");
					pstmt.setInt(2, start);
					pstmt.setInt(3, pageCnt);
				}
				rs = pstmt.executeQuery();
			}
			while(rs.next()) {
				NoticeDTO notice = new NoticeDTO();
				notice.setNum(rs.getInt("num"));
				notice.setTitle(rs.getString("title"));
				notice.setDate(rs.getString("date"));
				notice.setId(rs.getString("id"));
				notice.setContent(rs.getString("content"));
				list.add(notice);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.close(con);
			DBUtil.close(rs);
			DBUtil.close(pstmt);
		}
		return list;
	}
}
