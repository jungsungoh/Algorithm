package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dto.userDTO;
import util.DBUtil;

public class userDao {
	
	public userDTO login(String user_id, String user_pw) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		userDTO user = null;
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select * from user where user_id = ? and user_pw = ?");
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, user_id);
			pstmt.setString(2, user_pw);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				user = new userDTO();
				user.setNum(rs.getInt("num"));
				user.setUser_id(rs.getString("user_id"));
				user.setUser_pw(rs.getString("user_pw"));
				user.setName(rs.getString("name"));
				user.setMail(rs.getString("mail"));
				user.setIs_admin(rs.getBoolean("is_admin"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(con);
		}
		return user;
	}
	public userDTO login(String user_id) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		userDTO user = null;
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select * from user where user_id = ?");
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, user_id);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				user = new userDTO();
				user.setNum(rs.getInt("num"));
				user.setUser_id(rs.getString("user_id"));
				user.setUser_pw(rs.getString("user_pw"));
				user.setName(rs.getString("name"));
				user.setMail(rs.getString("mail"));
				user.setIs_admin(rs.getBoolean("is_admin"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(con);
		}
		return user;
	}
	public int register(userDTO user1) {
		Connection con = null;
		PreparedStatement pstmt = null;
		int flag = 0;
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO user (user_id, user_pw, name, mail, is_admin) VALUES(?, ?, ?, ?,false)");
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, user1.getUser_id());
			pstmt.setString(2, user1.getUser_pw());
			pstmt.setString(3, user1.getName());
			pstmt.setString(4, user1.getMail());
			flag = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.close(pstmt);
			DBUtil.close(con);
		}
		return flag;
	}
}
