package dto;

public class userDTO {
	private int num;
	private String user_id, user_pw, name ,mail;
	private boolean is_admin;
	public userDTO() {}
	public userDTO(int num, String user_id, String user_pw, String name, String mail, boolean is_admin) {
		super();
		this.num = num;
		this.user_id = user_id;
		this.user_pw = user_pw;
		this.name = name;
		this.mail = mail;
		this.is_admin = is_admin;
	}
	public userDTO(String user_id, String user_pw, String name, String mail) {
		super();
		this.user_id = user_id;
		this.user_pw = user_pw;
		this.name = name;
		this.mail = mail;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_pw() {
		return user_pw;
	}
	public void setUser_pw(String user_pw) {
		this.user_pw = user_pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public boolean isIs_admin() {
		return is_admin;
	}
	public void setIs_admin(boolean is_admin) {
		this.is_admin = is_admin;
	}
	
}
