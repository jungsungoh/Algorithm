package service;

import java.util.List;

import dao.NoticeDao;
import dto.NoticeDTO;


public class NoticeService {
	NoticeDao noticedao;
	
	public NoticeService(){
		noticedao = new NoticeDao();
	}
	public List<NoticeDTO> selectPage(int start, int pageCnt){
		return noticedao.selectPage(start, pageCnt);
	}
	public int selectCnt() {
		return noticedao.selectCnt();
	}
	public int selectCnt(int flag, String val) {
		return noticedao.selectCnt(flag, val);
	}
	public List<NoticeDTO> search_opt(int flag,String val,int start, int pageCnt){
		return noticedao.search_opt(flag, val, start, pageCnt);
	}
}
