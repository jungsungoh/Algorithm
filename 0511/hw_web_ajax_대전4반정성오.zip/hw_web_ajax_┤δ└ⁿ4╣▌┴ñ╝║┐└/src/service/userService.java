package service;

import dao.userDao;
import dto.userDTO;

public class userService {
	private userDao dao;
	public userService() {
		dao = new userDao();
	}
	
	public userDTO login(String user_id, String user_pw) {
		if(user_id == null || user_pw == null) {
			return null;
		}else {
			userDTO user = dao.login(user_id, user_pw);
			return user;
		}
	}
	public userDTO login(String user_id) {
		if(user_id == null) {
			return null;
		}else {
			userDTO user = dao.login(user_id);
			return user;
		}
	}
	public int register(userDTO user1) {
		int flag = dao.register(user1);
		return flag;
	}
}
