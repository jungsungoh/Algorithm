package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.ProductDto;
import service.ProductService;

@WebServlet("/main.do")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private ProductService productService;
    public void init() {
    	productService = new ProductService();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		process(request,response);
	}
	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		String root = request.getContextPath();
		String act = request.getParameter("act");
		
		if(act.equals("input")) {
			path = "/input_page.jsp";
			response.sendRedirect(root+path);
		}else if(act.equals("input_page")) {
			input(request,response);
		}else if(act.equals("select_all")) {
			select_all(request,response);
		}else if(act.equals("select")) {
			select(request,response);
		}else if(act.equals("all_li")) {
			select_all(request,response);
		}
		else if(act.equals("return")) {
			path = "/index.jsp";
			response.sendRedirect(root+path);
		}else if(act.equals("delete")) {
			path = "/delete.jsp";
			response.sendRedirect(root+path);
		}else if(act.equals("delete_page")) {
			delete(request, response);
		}
	}
	private void input(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int num = Integer.parseInt(request.getParameter("p_num"));
		String name = request.getParameter("p_name");
		int price = Integer.parseInt(request.getParameter("p_price"));
		String desc = request.getParameter("p_desc");
		String path = "/index.jsp";
		if(productService.insert_data(num,name,price,desc)){
			path = "/index.jsp";
			request.setAttribute("msg", "상품 정보 입력 완료!");
		}else {
			path = "/fail.jsp";
			request.setAttribute("msg", "상품 정보 입력에 실패하였습니다.");
		}
		request.getRequestDispatcher(path).forward(request, response);;
	}
	private void select_all(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<ProductDto> list = productService.select_all();
		String path = "/index.jsp";
		if(list== null) {
			path = "/fail.jsp";
			request.setAttribute("msg", "입력된 상품이 없습니다.");
		}else {
			path = "/list.jsp";
			request.setAttribute("plist", list);
		}
		request.getRequestDispatcher(path).forward(request, response);
	}
	private void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int num = Integer.parseInt(request.getParameter("p_num"));
		String path = "/index.jsp";
		if(productService.delete(num)) {
			path = "/index.jsp";
			request.setAttribute("msg", "삭제가 완료되었습니다!");
		}else {
			path = "/fail.jsp";
			request.setAttribute("msg", "삭제할 데이터가 없습니다");
		}
		request.getRequestDispatcher(path).forward(request, response);
	}
	private void select(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String s_num = request.getParameter("p_num");
		String s_price = request.getParameter("p_price");
		int num = 0;
		int price = 0;
		if(s_num !="" && s_price =="") {
			num = Integer.parseInt(s_num);
		}else if(s_num =="" && s_price !="") {
			price = Integer.parseInt(s_price);
		}else {
			num = Integer.parseInt(s_num);
			price = Integer.parseInt(s_price);
		}
		List<ProductDto> list = productService.select(num, price);
		String path = "/index.jsp";
		if(list == null) {
			path = "/fail.jsp";
			request.setAttribute("msg", "조회 상품이 없습니다.");
		}else {
			path = "/list.jsp";
			request.setAttribute("plist", list);
		}
		request.getRequestDispatcher(path).forward(request, response);
	}
}
