package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dto.ProductDto;
import util.DBUtil;

public class ProductDao {
	
	public int insert_data(int num, String name, int price, String desc) {
		Connection con = null;
		PreparedStatement pstmt = null;
		int flag = 0;
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("insert into product(p_num, p_name, p_price, p_desc) \n");
			sql.append("values(?,?,?,?)");
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, num);
			pstmt.setString(2, name);
			pstmt.setInt(3, price);
			pstmt.setString(4, desc);
			flag = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.close(con);
			DBUtil.close(pstmt);
		}
		return flag;
	}
	public List<ProductDto> select_all() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<ProductDto> list = new ArrayList<>();
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select * from product");
			pstmt = con.prepareStatement(sql.toString());
			rs= pstmt.executeQuery();
			while(rs.next()) {
				ProductDto dto = new ProductDto();
				dto.setNum(rs.getInt("p_num"));
				dto.setName(rs.getString("p_name"));
				dto.setPrice(rs.getInt("p_price"));
				dto.setDesc(rs.getString("p_desc"));
				list.add(dto);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.close(rs);
			DBUtil.close(con);
			DBUtil.close(pstmt);
		}
		return list;
	}
	public int delete(int num) {
		Connection con = null;
		PreparedStatement pstmt = null;
		int flag = 0;
		try {
			con = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("delete from product where p_num = ?");
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, num);
			flag = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.close(con);
			DBUtil.close(pstmt);
		}
		return flag;
	}
	public List<ProductDto> select(int num, int price) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<ProductDto> list = new ArrayList<>();
		try {
			con = DBUtil.getConnection();
			StringBuffer sql = new StringBuffer();
			if(num ==0 && price !=0) {
				sql.append("select * from product where p_price <= ?");
				pstmt = con.prepareStatement(sql.toString());
				pstmt.setInt(1, price);
			}else if(num != 0 && price ==0) {
				sql.append("select * from product where p_num = ?");
				pstmt = con.prepareStatement(sql.toString());
				pstmt.setInt(1, num);
			}else {
				sql.append("select * from product where p_price = ? and p_num = ?");
				pstmt = con.prepareStatement(sql.toString());
				pstmt.setInt(1, price);
				pstmt.setInt(2, num);
			}
			rs = pstmt.executeQuery();
			while(rs.next()) {
				ProductDto dto = new ProductDto();
				dto.setNum(rs.getInt("p_num"));
				dto.setName(rs.getString("p_name"));
				dto.setPrice(rs.getInt("p_price"));
				dto.setDesc(rs.getString("p_desc"));
				list.add(dto);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.close(rs);
			DBUtil.close(con);
			DBUtil.close(pstmt);
		}
		return list;
		
	}
}
