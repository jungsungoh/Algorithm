package service;

import java.util.List;

import dao.ProductDao;
import dto.ProductDto;

public class ProductService {
	private ProductDao dao;
	public ProductService(){
		dao = new ProductDao();
	}
	public boolean insert_data(int num, String name, int price, String desc) {
		if(dao.insert_data(num,name,price,desc) ==0) {
			return false;
		}
		else {
			return true;
		}
	}
	public List<ProductDto> select_all(){
		return dao.select_all();
	}
	public List<ProductDto> select(int num, int price){
		return dao.select(num,price);
	}
	public boolean delete(int num) {
		if(dao.delete(num) == 0) {
			return false;
		}else {
			return true;
		}
	}
}
