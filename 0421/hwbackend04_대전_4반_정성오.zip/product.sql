CREATE TABLE Product (
	p_num int,
    p_name VARCHAR(20) NULL,
    P_price int,
    p_desc VARCHAR(100) NULL
);