/**
 * MyMap 생성자로 사용될 함수를 구현
 */
function MyMap(){
    this.data = {};
    this.cnt = 0;
}

MyMap.prototype.put = function(key,val) {
    this.data[key] = val;
    this.cnt++;
}

MyMap.prototype.size = function(){
    return this.cnt;
}

MyMap.prototype.get = function(key){
    return this.data[key];
}

MyMap.prototype.remove = function(key){
    delete this.data[key];
    this.cnt--;
}

MyMap.prototype.clear = function(){
    delete this.data;
    this.cnt = 0;
}