package swexpert;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

/*
3 3
1 2 1
2 3 2
1 3 3
 */
public class Mun_kruskal {
	static int[] parents;
	static int[] rank;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int v = sc.nextInt();
		int e = sc.nextInt();
		parents = new int[v];
		rank = new int[v];
		point[] p = new point[e];
		for(int i=0; i<e; i++) {
			p[i] = new point(sc.nextInt()-1,sc.nextInt()-1,sc.nextInt());
		}
		Arrays.sort(p, new Comparator<point>() {
			@Override
			public int compare(point o1, point o2) {
				// TODO Auto-generated method stub
				return Integer.compare(o1.val , o2.val);
			}
		});
		for(int i=0; i<v; i++) {
			makeSet(i);
		}
		int cnt = 0;
		int result = 0;
		for(int i=0; i<e; i++) {
			int a = findSet(p[i].start);
			int b = findSet(p[i].end);
			if(a==b) continue;
			union(a,b);
			result += p[i].val;
			cnt++;
			if(cnt == v-1)
				break;
		}
		System.out.println(result);
		System.out.println(Arrays.toString(parents));
	}
	static void makeSet(int x) {
		parents[x] = x;
	}
	static int findSet(int x) {
		if(x==parents[x]) {
			return x;
		}
		else {
			parents[x] = findSet(parents[x]);
			return findSet(parents[x]);
		}
	}
	static void union(int x, int y) {
		int px = findSet(x);
		int py = findSet(y);
		if(rank[px] > rank[py]) {
			parents[py] = px;
		}else {
			parents[px] = py;
			if(rank[px] == rank[py]) {
				rank[py]++;
			}
		}
	}
	static class point{
		int start, end, val;

		public point(int start, int end, int val) {
			super();
			this.start = start;
			this.end = end;
			this.val = val;
		}
	}
}
