package swexpert;

import java.util.Arrays;
import java.util.Scanner;

/*
3 3
1 2 1
2 3 2
1 3 3
 */
public class Mun_prim {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int V= sc.nextInt();
		int E = sc.nextInt();
		int[][] adj = new int[V+1][V+1];
		
		for(int i=0; i<E; i++) {
			int a = sc.nextInt();
			int b = sc.nextInt();
			int c = sc.nextInt();
			adj[a][b] = c;
			adj[b][a] = c;
		}
		
		boolean[] check = new boolean[V+1];
		int[] key = new int[V+1];
		int[] p = new int[V+1];
		Arrays.fill(key,  Integer.MAX_VALUE);
		
		p[1] = -1;
		key[1] = 0;
		for(int i=0; i<V-1; i++) {
			int min = Integer.MAX_VALUE;
			int index = -1;
			for(int j=1; j<=V; j++) {
				if(!check[j] && key[j] <min) {
					index = j;
					min = key[j];
				}
			}
			check[index] = true;
			for(int j=1; j<=V; j++) {
				if(!check[j] && adj[index][j] != 0 && key[j] > adj[index][j] ) {
					p[j] = index;
					key[j] = adj[index][j];
				}
			}
		}
		int result = 0;
		for(int i=1; i<=V; i++) {
			result += key[i];
		}
		System.out.println(result);
	}
}
