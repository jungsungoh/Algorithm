package swexpert;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Scanner;

/*
3 3
1 2 1
2 3 2
1 3 3
 */
public class Mun_prim_pq {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int v= sc.nextInt();
		int e = sc.nextInt();
		ArrayList<point>[] al = new ArrayList[v+1];
		for(int i=1; i<v+1; i++) {
			al[i] = new ArrayList<>();
		}
		PriorityQueue<point> pq = new PriorityQueue<>(new Comparator<point>() {
			@Override
			public int compare(point o1, point o2) {
				// TODO Auto-generated method stub
				return o1.val - o2.val;
			}
		});
		boolean[] visited = new boolean[v+1];
		for(int i=0; i<e; i++) {
			int a = sc.nextInt();
			int b = sc.nextInt();
			int c = sc.nextInt();
			al[a].add(new point(b,c));
			al[b].add(new point(a,c));
		}
		Queue<Integer> q = new LinkedList<>();
		q.add(1);
		int result = 0;
		while(!q.isEmpty()) {
			int cur = q.poll();
			visited[cur] = true;

			for(point p : al[cur]) {
				if(!visited[p.next_v]) {
					pq.add(p);
				}
			}
			while(!pq.isEmpty()) {
				point p = pq.poll();
				if(visited[p.next_v]) continue;
				q.add(p.next_v);
				visited[p.next_v] = true;
				result+= p.val;
				break;
			}
		}
		System.out.println(result);
	}
		
	static class point{
		int next_v, val;

		public point(int next_v, int val) {
			super();
			this.next_v = next_v;
			this.val = val;
		}
		
	}
}

