package controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ssafy.dto.Product;
import com.ssafy.service.ProductService;



@Controller
public class ProductController {
	@Autowired
	private ProductService service;
	@RequestMapping(method = RequestMethod.GET, value = "/addForm.do")
	public String addForm() { 
		return "product_form"; 
	} 
	
	@RequestMapping(method = RequestMethod.POST, value ="/productAdd.do")
	public String insert(Product product){
		if(service.insert(product) >0) {
			return "add_success";
		}else {
			return "add_fail";
		}
	}
	@RequestMapping(method = RequestMethod.GET, value = "/productList.do")
	public String cccc(Model model){
		model.addAttribute("pList", service.selectAll());
		return "list";
	}
}
