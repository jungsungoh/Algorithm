package com.ssafy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.dao.ProductRepo;
import com.ssafy.dto.Product;

@Service
public class ProductServiceImpl implements ProductService{
	@Autowired
	private ProductRepo productRepo;
	ProductServiceImpl(ProductRepo repo){
		productRepo = repo;
	}
	@Override
	public ProductRepo getRepo() {
		return productRepo;
	}

	@Override
	public List<Product> selectAll() {
		return productRepo.selectAll();
	}

	@Override
	public Product select(String id) {
		return productRepo.select(id);
	}

	@Override
	public int insert(Product product) {
		return productRepo.insert(product);
	}

	@Override
	public int update(Product product) {
		return productRepo.update(product);
	}

	@Override
	public int delete(String id) {
		return productRepo.delete(id);
	}

}
