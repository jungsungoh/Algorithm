package com.ssafy.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import com.ssafy.dto.Product;

@Repository
public class ProductRepoImpl implements ProductRepo{
	
	private SqlSessionTemplate template;
	@Override
	public List<Product> selectAll() {
		return template.selectList("product-mapper.selectAllProduct");
	}

	@Override
	public Product select(String id) {
		System.out.println("상품 조회 성공!");
		return null;
	}

	@Override
	public int insert(Product product) {
		return template.insert("product-mapper.insertProduct");
	}

	@Override
	public int update(Product product) {
		System.out.println("상품 갱신 성공!");
		return 0;
	}

	@Override
	public int delete(String id) {
		System.out.println("상품 삭제 성공!");
		return 0;
	}

}
