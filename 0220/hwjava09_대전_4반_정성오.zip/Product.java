package hw;

import java.io.Serializable;

public class Product implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int bun, price, num;
	private String name;
	public Product(int bun, int price, int num, String name) {
		this.bun = bun;
		this.price = price;
		this.num = num;
		this.name = name;
	}
	public int getBun() {
		return bun;
	}
	public void setBun(int bun) {
		this.bun = bun;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Product [bun=" + bun + ", price=" + price + ", num=" + num + ", name=" + name + "]";
	}
	
	public int equals(Product o) {
		if(this.bun == o.getBun() && this.price == o.getPrice() && this.num == o.getNum() && this.name.equals(o.getName())) {
			return 0;
		}
		else {
			return 1;			
		}
	}
	
}
