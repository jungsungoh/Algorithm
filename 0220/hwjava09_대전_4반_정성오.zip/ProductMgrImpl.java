package hw;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;


public class ProductMgrImpl implements IProductMgr{
	static ArrayList<Product> al = new ArrayList<>();
	@Override
	public void Input(Product b) throws DuplicateException {
		for(int i=0; i<al.size(); i++) {
			if(al.get(i).equals(b) == 0) {
				throw new DuplicateException();
			}
		}
		al.add(b);
	}
	public ProductMgrImpl() throws FileNotFoundException, ClassNotFoundException, IOException {
		open();
	}
	@Override
	public void search() {
		// TODO Auto-generated method stub
		for(int i=0; i<al.size(); i++) {
			System.out.println(al.get(i));
		}
	}

	@Override
	public void search_bunho(int bunho) throws CodeNotFoundException {
		// TODO Auto-generated method stub
		int flag = 0;
		for(int i=0; i<al.size(); i++) {
			if(al.get(i).getBun()== bunho) {
				System.out.println(al.get(i));
				flag = 1;
			}
		}
		if(flag == 0) {
			throw new CodeNotFoundException();
		}
	}

	@Override
	public void search_name(String name) {
		// TODO Auto-generated method stub
		for(int i=0; i<al.size(); i++) {
			if(al.get(i).getName().contains(name)) {
				System.out.println(al.get(i));
			}
			
		}
	}

	@Override
	public void search_TV() {
		// TODO Auto-generated method stub
		for(int i=0; i<al.size(); i++) {
			if(al.get(i) instanceof TV) {
				System.out.println(al.get(i));
			}
		}
	}

	@Override
	public void search_Refrigerator() {
		// TODO Auto-generated method stub
		for(int i=0; i<al.size(); i++) {
			if(al.get(i) instanceof Refrigerator) {
				System.out.println(al.get(i));
			}
		}
	}

	@Override
	public void search_up400() throws ProductNotFoundException {
		// TODO Auto-generated method stub
		int flag = 0;
		for(int i=0; i<al.size(); i++) {
			if(al.get(i) instanceof TV) {
				flag =1;
				TV t = (TV)al.get(i);
				if(t.getInch() >= 400) {
					System.out.println(t);
				}
			}
		}
		if(flag == 0) {
			throw new ProductNotFoundException();
		}
	}

	@Override
	public void search_up50() throws ProductNotFoundException {
		// TODO Auto-generated method stub
		int flag = 0;
		for(int i=0; i<al.size(); i++) {
			if(al.get(i) instanceof Refrigerator) {
				Refrigerator t = (Refrigerator)al.get(i);
				if(t.getL() >= 50) {
					flag =1;
					System.out.println(t);
				}
			}
		}
		if(flag == 0) {
			throw new ProductNotFoundException();
		}
	}

	@Override
	public void search_price(int bun, int price) {
		// TODO Auto-generated method stub
		for(int i=0; i<al.size(); i++) {
			if(al.get(i).getBun() == bun) {
				al.get(i).setPrice(price);
			}
		}
	}

	@Override
	public void delete_p(int bun) {
		// TODO Auto-generated method stub
		for(int i=0; i<al.size(); i++) {
			if(al.get(i).getBun() == bun) {
				al.remove(i);
			}
		}
		
	}

	@Override
	public void print_sum() {
		// TODO Auto-generated method stub
		int sum = 0;
		// TODO Auto-generated method stub
		for(int i=0; i<al.size(); i++) {
			sum += al.get(i).getPrice();	
		}
		System.out.println("����� ��� ����� �ݾ� �հ�� " +sum);
	}
	public void open() throws FileNotFoundException, IOException, ClassNotFoundException {
		ObjectInputStream is;
		while(true) {	
		try {
			is = new ObjectInputStream(new FileInputStream("Product.dat"));
		}catch(EOFException e) { 
			return;
		}
		while(true) {
			try {				
				al.add((Product)is.readObject());
			}
			catch(EOFException e) {
				return;
			}
		}
		}
	}
	// ���α׷� ����ÿ� ȣ��Ǿ� ����, ArrayList�� �ִ� ���� ������ ���Ϸ� �����Ѵ�
	public void close() throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("Product.dat"));
		for(int i=0; i<al.size(); i++) {
			os.writeObject(al.get(i));
		}
		os.close();
		System.out.println("���α׷� ����");
	}
}
