package hw;

import java.io.Serializable;

public class TV extends Product implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int inch;

	public TV(int bun, int price, int num, String name, int inch) {
		super(bun, price, num, name);
		this.inch = inch;
	}

	public int getInch() {
		return inch;
	}

	public void setInch(int inch) {
		this.inch = inch;
	}

	@Override
	public String toString() {
		String s = super.toString() + "TV [inch=" + inch + "]";
		return s;
	}
	
}
