package hw;

public interface IProductMgr {
	void Input(Product b) throws DuplicateException;
	void search();
	void search_bunho(int bunho) throws CodeNotFoundException;
	void search_name(String name);
	void search_TV();
	void search_Refrigerator();
	void search_up400() throws ProductNotFoundException;
	void search_up50() throws ProductNotFoundException;
	void search_price(int bun,int price);
	void delete_p(int bun);
	void print_sum();
	
}
