package hw;

import java.io.Serializable;

public class Refrigerator extends Product implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int L;
	public Refrigerator(int bun, int price, int num, String name, int l) {
		super(bun, price, num, name);
		L = l;
	}

	public int getL() {
		return L;
	}

	public void setL(int l) {
		L = l;
	}

	@Override
	public String toString() {
		String s = super.toString() + "Refrigerator [L=" + L + "]";
		return s;
	}
	
}
