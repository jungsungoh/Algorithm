package com.ssafy.myapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hw5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
