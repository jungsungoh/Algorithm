package com.ssafy.product.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ProductController2 {
	@GetMapping("/")
	public String sd() {
		return "main";
	}
}
