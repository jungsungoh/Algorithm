package com.ssafy.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.product.dao.ProductDao;
import com.ssafy.product.dto.ProductDTO;


@Service
public class ProductServiceImpl implements ProductService{
	@Autowired
	ProductDao dao;
	
	@Override
	public int registry(ProductDTO p) {
		return dao.insert(p);
	}

	@Override
	public int modify(ProductDTO p) {
		return dao.update(p);
	}

	@Override
	public int remove(int no) {
		return dao.delete(no);
	}

	@Override
	public List<ProductDTO> findAll() {
		return dao.selectAll();
	}
	@Override
	public ProductDTO find(int no) {
		return dao.select(no);
	}
}
