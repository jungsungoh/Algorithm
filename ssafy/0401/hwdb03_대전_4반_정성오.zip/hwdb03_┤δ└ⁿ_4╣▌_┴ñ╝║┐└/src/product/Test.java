package product;

import java.util.List;

public class Test {
	public static void main(String[] args) {
		productDAO dao = new productDAO();
		product p1 = new product(5555,"5555",5555);
		dao.insertProduct(p1);
		List<product> al = dao.listProduct();
		for(product p : al) {
			System.out.println(p);
		}
		System.out.println("=================");
		product up = new product(5555,"6666",6666);
		dao.updateProduct(up);
		al = dao.listProduct();
		for(product p : al) {
			System.out.println(p);
		}
		System.out.println("=================");
		dao.deleteProduct(5555);
		al = dao.listProduct();
		for(product p : al) {
			System.out.println(p);
		}
		
	}
}
