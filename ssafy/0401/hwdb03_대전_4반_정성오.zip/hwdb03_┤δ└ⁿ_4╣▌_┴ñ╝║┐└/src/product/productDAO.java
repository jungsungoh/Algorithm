package product;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class productDAO {
	static private Connection conn;
	public productDAO() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() {
			try {
				conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8","ssafy","ssafy");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return conn;
	}
	
	public void insertProduct(product p) {
		conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into product(code, name ,price)values(?,?,?)";
		
		conn = getConnection();
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1,p.getCode());
			pstmt.setString(2, p.getName());
			pstmt.setInt(3,  p.getPrice());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try{if(conn!=null)conn.close();}catch(Exception e) {};
		try{if(pstmt!=null)pstmt.close();}catch(Exception e) {};
	}
	
	public void updateProduct(product p) {
		conn = null;
		PreparedStatement pstmt = null;
		String sql = "update product set code = ? , name = ?, price = ? where code = ?";
		conn = getConnection();
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, p.getCode());
			pstmt.setString(2, p.getName());
			pstmt.setInt(3, p.getPrice());
			pstmt.setInt(4, 5555);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try{if(conn!=null)conn.close();}catch(Exception e) {};
		try{if(pstmt!=null)pstmt.close();}catch(Exception e) {};
	}
	public void deleteProduct(int code) {
		conn = null;
		Statement st = null;
		try {
			conn = getConnection();
			String sql = "delete from product where code = "+ code;
			st = conn.createStatement();
			st.executeUpdate(sql);
		}catch(Exception e) {
			e.printStackTrace();
		}
		try{if(conn!=null)conn.close();}catch(Exception e) {};
		try{if(st!=null)st.close();}catch(Exception e) {};
		
	}
	
	public List<product> listProduct() {
		conn = null;
		List<product> al = new ArrayList<>();
		Statement st = null;
		ResultSet rs = null;
		conn = getConnection();
		String sql = "select * from product";
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while(rs.next()) {
				al.add(new product(rs.getInt("code"),rs.getString("name"),rs.getInt("price")));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try{if(conn!=null)conn.close();}catch(Exception e) {};
		try{if(st!=null)st.close();}catch(Exception e) {};
		try{if(rs!=null)rs.close();}catch(Exception e) {};
		return al;
	}
}
