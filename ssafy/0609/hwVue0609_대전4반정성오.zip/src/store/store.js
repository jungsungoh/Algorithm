import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'

Vue.use(Vuex)

export default new Vuex.Store({
    state:{
        items:[],
    },
    getters:{
        items(state){
            return state.items;
        }
    },
    mutations:{
        setItems(state, payload){
            state.items = payload;
        }
    },
    actions:{
        getItems(context){
            axios.get('http://localhost:8080/ssafy/api/employee/all')
              .then((result)=>{
                   console.log(result);
                   context.commit('setItems',result.data);
               })
        }
    },
    modules:{

    }
})