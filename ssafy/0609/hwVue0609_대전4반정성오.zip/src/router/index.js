import Vue from "vue";
import VueRouter from "vue-router";
import List from '@/components/List.vue';
import Regist from '@/components/Regist.vue';
import Read from '@/components/Read.vue';
import Delete from '@/components/Delete.vue';
Vue.use(VueRouter);

export default new VueRouter({
    mode: 'history',
    routes:[
        {
            path:'/list',
            name:'list',
            component:List
        },
        {
            path:'/regist',
            name:'regist',
            component:Regist
        },
        {
            path: '/read',
            name: 'read',
            component:Read
        },
        {
            path: '/delete',
            name: 'delete',
            component:Delete
        }

    ]
})