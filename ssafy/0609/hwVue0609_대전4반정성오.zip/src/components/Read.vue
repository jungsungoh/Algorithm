<template>
    <div>
        <h2 class = "text-center">사원 정보보기</h2>
        <div>
            <table class = "table table-bordered w-50">
                <tr>
                    <th>사원번호</th>
                    <td>{{item.id}}</td>
                </tr>
                <tr>
                    <th>사원명</th>
                    <td>{{item.name}}</td>
                </tr>
                <tr>
                    <th>부서</th>
                    <td>{{item.dept_id}}</td>
                </tr>
                <tr>
                    <th>직책</th>
                    <td>{{item.title}}</td>
                </tr>
                <tr>
                    <th>연봉</th>
                    <td>{{item.salary}}</td>
                </tr>
            </table>
        <br />
        <div class="text-center">
            <router-link :to="'/list'"><button class="btn btn-primary">목록</button></router-link>
            <router-link :to="'/delete?no=' + item.id"><button class="btn btn-primary">삭제</button></router-link>
        </div>
    </div>
    </div>
</template>

<script>
import axios from "axios";
import {mapGetters} from 'vuex';
export default {
    name : 'Read',
    data(){
        return{
            item: []
        }
    },
    computed:{
        ...mapGetters(['items'])
    },
    created() {
        this.$store.dispatch('getItems');
        const params = (new URL(document.location)).searchParams;
        axios.get('http://localhost:8080/ssafy/api/employee/all')
        .then((result)=>{
            for(let it in result.data){
                if(result.data[it].id==params.get('no')){
                    this.item = result.data[it];
                }
            }
        })
    },

}
</script>

<style>

</style>