<template>
  <div>
        <table>
        <tr>
          <td>이름</td>
         <td><input type="text" id="name" v-model="name"></td>
        </tr>
        <tr>
        <td>이메일</td>
        <td><input type="text" id="email"  v-model="email"></td>
    <tr>
        <td>고용일</td>
        <td><input type="text" id="day" placeholder="연도-월-일" v-model="day"></td>
    </tr>
    <tr>
        <td>관리자</td>
        <td><input type="text" id="admin" v-model="admin"></td>
    </tr>
    <tr>
        <td>직책</td>
        <td><select v-model="class1" id ="class1" name="class1">
                <option value="사장">사장</option>
                <option value="기획부장">기획부장</option>
                <option value="영업부장">영업부장</option>
                <option value="총무부장">총무부장</option>
                <option value="인사부장">인사부장</option>
                <option value="과장">과장</option>
                <option value="영업대표이사">영업대표이사</option>
                <option value="사원">사원</option>
            </select>
        </td>
    </tr>
    <tr>
        <td>부서</td>
        <td><input type="text" id="depart" v-model="depart"></td>
        </tr>
        <tr>
            <td>월급</td>
            <td><input type="text" id="salary" v-model="salary"></td>
        </tr>
        <tr>
            <td>커미션</td>
            <td><input type="text" id="comission" v-model="comission"></td>
        </tr>
    </table>

    <div class="text-right">
        <button class="btn btn-primary" @click="checkHandler">등록</button>
    </div>
    </div>
</template>

<script>
import axios from 'axios';
export default {
    name : "Regist",
    data(){ 
        return {
        name:'',
        email:'',
        day:'',
        admin:'',
        class1:'',
        depart:'',
        salary:'',
        comission:''
    }},
    methods: {
        checkHandler(){
            let isOk = true;
            if(!this.name || !this.email || !this.day|| !this.admin|| !this.class1|| !this.depart||!this.comission||!this.salary){
                isOk=false;
            }
            if(isOk){
                this.createHandler();
            }else{
                alert("비어있는 항목을 입력해주세요!")
            }
        },

        createHandler() {
           axios.post('http://localhost:8080/ssafy/api/employee',
            {     
                name: this.name,
                email: this.email,
                day: this.day,
                admin: this.admin,
                class1: this.class1,
                depart: this.depart,
                salary: this.salary,
                comission: this.comission
            }
            ).then(({data})=>{
                if(data == 'success'){
                    alert('등록이 완료되었습니다.');
                }else{
                    alert('등록 과정에 문제가 발생하였습니다.');
                }
                this.moveList();
            });
        }
        ,
        moveList() {
            this.$router.push('/');
        }
    }
}
</script>

<style>

</style>