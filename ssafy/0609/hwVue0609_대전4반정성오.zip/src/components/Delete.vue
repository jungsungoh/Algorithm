<template>
  <div>
    <h2 class="text-center">Vue를 이용한 게시판</h2>
    <div>
      삭제중...
    </div>
  </div>
</template>

<script>
import axios from 'axios';
export default {
    name: 'delete',
    created() {
    const params = (new URL(document.location)).searchParams;
    axios.delete('http://localhost:8080/ssafy/api/employee/' + params.get("no"))
    .then(({ data }) => {
      if (data == 'success')
        alert('삭제가 완료되었습니다.');

      this.$router.push('/list');
    })
  }
}
</script>

<style>

</style>