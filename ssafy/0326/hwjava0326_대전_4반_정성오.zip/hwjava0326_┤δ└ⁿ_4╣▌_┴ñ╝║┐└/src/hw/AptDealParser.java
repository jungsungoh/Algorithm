package hw;

import java.io.File;
import java.util.List;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;


public class AptDealParser {
	private String filePath = "./src/AptDealHistory.xml";
	private static List<AptDeal> result;
	public AptDealParser(String AptName) {
		File file = new File(filePath);
		SAXParser parser = null;
		try {
			SAXParserFactory factory = SAXParserFactory.newInstance();
			parser = factory.newSAXParser();
			AptDealHandler handler = new AptDealHandler(AptName);
			parser.parse(file, handler);
			result = handler.getList();
		} catch (SAXParseException spe) {
			System.out.println(spe.getMessage());
			System.exit(0);
		} catch (SAXException se) {
			System.out.println(se.getMessage());
			System.exit(0);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			System.exit(0);
		}
	}
	public static void main(String[] args) {
		AptDealParser parser = new AptDealParser("경희");
		for(int i=0; i<result.size(); i++) {
			System.out.println(result.get(i));
		}
	}
}
