package hw;

import java.util.ArrayList;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


public class AptDealHandler extends DefaultHandler{
	private AptDeal apt;
	private ArrayList<AptDeal> list;
	private String temp;
	private String aptname;
	private boolean flag;
	
	public AptDealHandler(String AptName) {
		list = new ArrayList<AptDeal>();
		aptname =AptName;
		flag = false;
	}
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		if(qName.equals("item")) {
			apt = new AptDeal();
		}
	}
	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		super.characters(ch, start, length);
		temp = String.valueOf(ch, start, length);
	}
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if(qName.equals("아파트")) {
			if(temp.contains(aptname)) {
				flag = true;
			}
			if(flag == true) {
				apt.setName(temp);
			}
		}
		if(flag&&qName.equals("법정동")) {
			apt.setDong(temp);
		}
		if(flag&&qName.equals("거래금액")){
			apt.setPrice(temp);
		}
		if(flag&&qName.equals("item")) {
			list.add(apt);
			flag = false;
			apt = null;
		}
	}
	
	public ArrayList<AptDeal> getList() {
		return list;
	}
}
