package hw;

public class AptDeal {
	private String Name, Dong, Price;

	public AptDeal() {};
	public AptDeal(String name, String dong, String price) {
		super();
		Name = name;
		Dong = dong;
		Price = price;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getDong() {
		return Dong;
	}

	public void setDong(String dong) {
		Dong = dong;
	}

	public String getPrice() {
		return Price;
	}

	public void setPrice(String price) {
		Price = price;
	}

	@Override
	public String toString() {
		return "AptDeal [Name=" + Name + ", Dong=" + Dong + ", Price=" + Price + "]";
	}

}
