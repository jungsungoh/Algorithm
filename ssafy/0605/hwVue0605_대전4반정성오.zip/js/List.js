export default{
    template: `
    <div>
    <div class="text-center">
        <input type="text" id="search" v-model="keyword">
        <button class="btn btn-primary" @click="searchId">검색</button>         
    </div>
        <div v-if="items.length">
        <table class="table table-bordered table-condensed">
            <colgroup>
                <col :style="{width: '20%'}" />
                <col :style="{width: '20%'}" />
                <col :style="{width: '20%'}" />
                <col :style="{width: '20%'}" />
                <col :style="{width: '20%'}" />
            </colgroup>
            <tr>
                <th>사원ID</th>
                <th>사원명</th>
                <th>부서</th>
                <th>직책</th>
                <th>연봉</th>
            </tr>
            <tr v-for="m in items">
                <td>{{m.id}}
                <td>{{m.name}}</td>
                <td>{{m.dept_id}}</td>
                <td>{{m.title}}</td>
                <td>{{m.salary*12}}</td>
            </tr>
        </table>
        </div>
        <div v-else class="text-center">
            게시글이 없습니다.
        </div>
        <div class="text-right">
            <button class="btn btn-primary" @click="movePage">등록</button>
        </div>
    </div>
    `,data(){
        return{
            items: [],
            keyword: ''
        }
    },
    created(){
               axios.get('http://localhost:8080/ssafy/api/employee/all')
               .then((result)=>{
                   console.log(result);
                   this.items = result.data;
               })
            },
            methods :{
                movePage() {
                    this.$router.push('/regist');
                },
                searchId() {
                    axios.get('http://localhost:8080/ssafy/api/employee/all')
                    .then((result)=>{
                        this.items=new Array();
                        if(this.keyword.length != 0){
                            for(let it in result.data){
                                if(result.data[it].name.includes(this.keyword)){
                                    this.items.push(result.data[it]);
                                }
                            }
                        }else{
                            this.items = result.data;
                        }
                    })
                    
                }
            }

}