export default{
    template:`
    <p>
      <router-link to="/list">게시판</router-link>    
    </p>
    `
}