import List from './js/List.js';
import Regist from './js/Regist.js';

Vue.use(VueRouter);

export default new VueRouter({
    mode: 'history',
    routes:[
        {
            path:'/list',
            name:'list',
            component:List
        },
        {
            path:'/regist',
            name:'regist',
            component:Regist
        }

    ]
})