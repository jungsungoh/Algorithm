export default{
    template: `
    <div>
    <div class="text-center">
        <input type="text" id="search" v-model="keyword">
        <button class="btn btn-primary" @click="searchId">검색</button>         
    </div>
        <div v-if="items.length">
        <table class="table table-bordered table-condensed">
            <colgroup>
                <col :style="{width: '25%'}" />
                <col :style="{width: '25%'}" />
                <col :style="{width: '25%'}" />
                <col :style="{width: '25%'}" />
            </colgroup>
            <tr>
                <th>사원명</th>
                <th>부서</th>
                <th>직책</th>
                <th>연봉</th>
            </tr>
            <tr v-for="m in items">
                <td>{{m.name}}</td>
                <td>{{m.depart}}</td>
                <td>{{m.class1}}</td>
                <td>{{m.salary*12}}</td>
            </tr>
        </table>
        </div>
        <div v-else class="text-center">
            게시글이 없습니다.
        </div>
        <div class="text-right">
            <button class="btn btn-primary" @click="movePage">등록</button>
        </div>
    </div>
    `,data(){
        return{
            items: [],
            keyword: ''
        }
    },
    created(){
                const member = localStorage.getItem('member');
                let newMember={
                    sequence: 0,
                    items:[]
                };

                if(member){
                    newMember = JSON.parse(member);
                }else{
                    localStorage.setItem('member',JSON.stringify(newMember));
                }
                this.items = newMember.items;
            },
            methods :{
                movePage() {
                    location.href="hrm_regist.html";
                },
                searchId() {
                    const member = localStorage.getItem('member');
                    let newMember={
                      sequence: 0,
                       items:[]
                    };

                    if(member){
                      newMember = JSON.parse(member);
                    }else{
                         localStorage.setItem('member',JSON.stringify(newMember));
                    }
                    
                    this.items = newMember.items;
                }
            }

}