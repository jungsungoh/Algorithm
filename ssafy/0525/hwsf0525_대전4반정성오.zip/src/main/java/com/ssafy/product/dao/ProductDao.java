package com.ssafy.product.dao;

import java.util.List;

import com.ssafy.product.dto.ProductDTO;

public interface ProductDao {
	public List<ProductDTO> selectAll();
	public int insert(ProductDTO p);
	public int update(ProductDTO p);
	public int delete(int no);
	public ProductDTO select(int no);
}
