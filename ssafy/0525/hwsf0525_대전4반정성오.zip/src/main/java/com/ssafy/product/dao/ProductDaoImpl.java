package com.ssafy.product.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.product.dto.ProductDTO;

@Repository
public class ProductDaoImpl implements ProductDao{
	@Autowired
	SqlSessionTemplate template;
	@Override
	public List<ProductDTO> selectAll() {
		return template.selectList("product-mapper.selectAll");
	}

	@Override
	public int insert(ProductDTO p) {
		return template.insert("product-mapper.insertProduct", p);
	}

	@Override
	public int update(ProductDTO p) {
		return template.update("product-mapper.updateProduct", p);
	}

	@Override
	public int delete(int no) {
		return template.delete("product-mapper.deleteProduct", no);
	}
	
	public ProductDTO select(int no) {
		return template.selectOne("product-mapper.select",no);
	}
}
