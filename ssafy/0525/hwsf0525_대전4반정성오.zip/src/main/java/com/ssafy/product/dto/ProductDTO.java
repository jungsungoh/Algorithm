package com.ssafy.product.dto;

public class ProductDTO {
	private int no;
	private String id, name, price, descript;

	public ProductDTO() {}
	public ProductDTO(String id, String name, String price, String desc) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.descript = desc;
	}
	public ProductDTO(int no, String id, String name, String price, String desc) {
		super();
		this.no = no;
		this.id = id;
		this.name = name;
		this.price = price;
		this.descript = desc;
	}
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getDesc() {
		return descript;
	}

	public void setDesc(String desc) {
		this.descript = desc;
	}

	@Override
	public String toString() {
		return "ProductDTO [id=" + id + ", name=" + name + ", price=" + price + ", desc=" + descript + "]";
	}
	
}
