package com.ssafy.product.service;

import java.util.List;

import com.ssafy.product.dto.ProductDTO;

public interface ProductService {
	public int registry(ProductDTO p);
	 public int modify(ProductDTO p);
	 public int remove(int no);
	 public List<ProductDTO> findAll();
	 public ProductDTO find(int no);
}
