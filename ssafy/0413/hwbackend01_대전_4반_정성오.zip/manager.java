package proudct;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/manager")
public class manager extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("product_name");
		String price = request.getParameter("product_price");
		String desc = request.getParameter("product_description");
		
		response.setContentType("text/html; charset = UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<body>");
		out.println("상품 명은 " + name + " 입니다.<br>");
		out.println("상품 가격은 " + price + " 입니다<br>");
		out.println("이 상품은 " + desc + " 입니다.");
		out.println("</body>");
		out.println("</html>");
	}
}
