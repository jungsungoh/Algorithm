package com.ssafy.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.dto.Product;

import util.DBUtil;


public class ProductRepoImpl implements ProductRepo{
	@Override
	public List<Product> selectAll() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Product> pList = new ArrayList<Product>();
		try {
			String sql = "SELECT * FROM product_TB";
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Product p1 = new Product();
				p1.setCode(rs.getInt("code"));
				p1.setName(rs.getString("name"));
				p1.setMaker(rs.getString("maker"));
				p1.setPrice(rs.getInt("price"));
				p1.setDesc(rs.getString("desc"));
				
				pList.add(p1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(con);
		}
		return pList;

	}

	@Override
	public Product select(String id) {
		System.out.println("상품 조회 성공!");
		return null;
	}

	@Override
	public int insert(Product product) {
		Connection con = null;
		String sql = "INSERT INTO PRODUCT_TB(code, name, maker, price, desc) VALUES(?,?,?,?,?)";
		PreparedStatement pstmt = null;
		int flag = 0;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, product.getCode());
			pstmt.setString(2, product.getName());
			pstmt.setString(3, product.getMaker());
			pstmt.setInt(4, product.getPrice());
			pstmt.setString(5, product.getDesc());
			flag = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBUtil.close(con);
			DBUtil.close(pstmt);
		}
		return flag;
	}

	@Override
	public int update(Product product) {
		System.out.println("상품 갱신 성공!");
		return 0;
	}

	@Override
	public int delete(String id) {
		System.out.println("상품 삭제 성공!");
		return 0;
	}

}
