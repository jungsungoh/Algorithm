package com.ssafy.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.dao.ProductRepo;
import com.ssafy.dto.Product;
@Service
public interface ProductService {
	public ProductRepo getRepo();
	public List<Product> selectAll();
	public Product select(String id);
	public int insert(Product product);
	public int update(Product product);
	public int delete(String id);
}
