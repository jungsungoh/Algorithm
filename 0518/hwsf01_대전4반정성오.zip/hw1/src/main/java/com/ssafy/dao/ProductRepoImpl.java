package com.ssafy.dao;

import java.util.List;

import com.ssafy.dto.Product;

public class ProductRepoImpl implements ProductRepo{
	@Override
	public List<Product> selectAll() {
		System.out.println("상품 전체 조회 성공!");
		return null;
	}

	@Override
	public Product select(String id) {
		System.out.println("상품 조회 성공!");
		return null;
	}

	@Override
	public int insert(Product product) {
		System.out.println("상품 입력 성공!");
		return 0;
	}

	@Override
	public int update(Product product) {
		System.out.println("상품 갱신 성공!");
		return 0;
	}

	@Override
	public int delete(String id) {
		System.out.println("상품 삭제 성공!");
		return 0;
	}

}
